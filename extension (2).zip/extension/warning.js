// warning.js - PhishingNet (FIXED - Confidence Bar Color)

document.addEventListener('DOMContentLoaded', function() {
    // Get parameters from URL
    const urlParams = new URLSearchParams(window.location.search);
    const blockedUrl = decodeURIComponent(urlParams.get('url') || 'Unknown URL');
    const confidence = parseFloat(urlParams.get('confidence')) || 0;
    const explanation = decodeURIComponent(urlParams.get('explanation') || '');
    const details = JSON.parse(decodeURIComponent(urlParams.get('details') || '[]'));

    // Display blocked URL
    document.getElementById('blockedUrl').textContent = blockedUrl;

    // ============================================================
    // CONFIDENCE BAR - FIXED with color
    // ============================================================
    const confidencePercent = Math.round(confidence * 100);
    document.getElementById('confidenceText').textContent = confidencePercent + '%';

    const confidenceFill = document.getElementById('confidenceFill');
    confidenceFill.style.width = confidencePercent + '%';

    // Remove all color classes first
    confidenceFill.classList.remove('phishing', 'suspicious', 'legitimate');

    // Apply correct color based on threshold
    if (confidence >= 0.65) {
        confidenceFill.classList.add('phishing');
    } else if (confidence >= 0.45) {
        confidenceFill.classList.add('suspicious');
    } else {
        confidenceFill.classList.add('legitimate');
    }

    // ============================================================
    // STATUS BADGE - Update based on threshold
    // ============================================================
    const statusBadge = document.getElementById('statusBadge');
    const tierBadge = document.getElementById('tierBadge');

    if (confidence >= 0.65) {
        statusBadge.textContent = '🚨 Phishing Detected!';
        statusBadge.className = 'subtitle phishing';
        tierBadge.textContent = '🚨 PHISHING';
        tierBadge.className = 'status-badge phishing';
    } else if (confidence >= 0.45) {
        statusBadge.textContent = '⚠️ Suspicious URL';
        statusBadge.className = 'subtitle suspicious';
        tierBadge.textContent = '⚠️ SUSPICIOUS';
        tierBadge.className = 'status-badge suspicious';
    } else {
        statusBadge.textContent = '✅ Legitimate URL';
        statusBadge.className = 'subtitle legitimate';
        tierBadge.textContent = '✅ LEGITIMATE';
        tierBadge.className = 'status-badge legitimate';
    }

    // ============================================================
    // Display reasons
    // ============================================================
    const reasonList = document.getElementById('reasonList');
    reasonList.innerHTML = '';

    let reasons = [];
    if (details && details.length > 0) {
        reasons = details;
    } else if (explanation) {
        reasons = [explanation];
    } else {
        reasons = ['Suspicious URL pattern detected'];
    }

    reasons.forEach(reason => {
        const li = document.createElement('li');
        li.textContent = reason;
        reasonList.appendChild(li);
    });

    // Store blocked URL globally
    window._blockedUrl = blockedUrl;
});

// ===================== BUTTON FUNCTIONS =====================

function goBack() {
    if (window.history.length > 1) {
        window.history.back();
    } else {
        window.location.href = 'https://www.google.com';
    }
}

function continueAnyway() {
    const url = window._blockedUrl;
    
    if (url) {
        try {
            chrome.runtime.sendMessage({
                action: 'continueAnyway',
                url: url
            });
        } catch (e) {}
        window.location.href = url;
    } else {
        window.history.back();
    }
}

// ===================== ATTACH BUTTON EVENTS =====================

setTimeout(function() {
    const goBackBtn = document.getElementById('goBackBtn');
    const continueBtn = document.getElementById('continueBtn');
    
    if (goBackBtn) {
        goBackBtn.addEventListener('click', goBack);
    }
    
    if (continueBtn) {
        continueBtn.addEventListener('click', continueAnyway);
    }
}, 100);