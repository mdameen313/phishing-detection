// warning.js - PhishingNet

document.addEventListener('DOMContentLoaded', function() {
    // Get parameters from URL
    const urlParams = new URLSearchParams(window.location.search);
    const blockedUrl = decodeURIComponent(urlParams.get('url') || 'Unknown URL');
    const confidence = parseFloat(urlParams.get('confidence')) || 0;
    const explanation = decodeURIComponent(urlParams.get('explanation') || '');
    const details = JSON.parse(decodeURIComponent(urlParams.get('details') || '[]'));

    // Display blocked URL
    document.getElementById('blockedUrl').textContent = blockedUrl;

    // Display confidence
    const confidencePercent = Math.round(confidence * 100);
    document.getElementById('confidenceText').textContent = confidencePercent + '%';
    document.getElementById('confidenceFill').style.width = confidencePercent + '%';

    // Display reasons
    const reasonList = document.getElementById('reasonList');
    reasonList.innerHTML = '';

    let reasons = [];
    if (details && details.length > 0) {
        reasons = details;
    } else if (explanation) {
        reasons = [explanation];
    } else {
        reasons = ['Suspicious URL pattern detected'];
    }

    reasons.forEach(reason => {
        const li = document.createElement('li');
        li.textContent = reason;
        reasonList.appendChild(li);
    });

    // Store blocked URL
    window._blockedUrl = blockedUrl;

    // ---- BUTTON EVENTS ----
    // Go Back Button
    document.getElementById('goBackBtn').addEventListener('click', function() {
        if (window.history.length > 1) {
            window.history.back();
        } else {
            window.location.href = 'https://www.google.com';
        }
    });

    // Continue Anyway Button
    document.getElementById('continueBtn').addEventListener('click', function() {
        const url = window._blockedUrl;
        if (url) {
            try {
                chrome.runtime.sendMessage({
                    action: 'continueAnyway',
                    url: url
                });
            } catch (e) {
                console.log('Runtime message error:', e);
            }
            window.location.href = url;
        } else {
            window.history.back();
        }
    });
});